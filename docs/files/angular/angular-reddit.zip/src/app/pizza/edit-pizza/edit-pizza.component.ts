import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Pizza } from '../model/pizza.model';

@Component({
  selector: 'app-edit-pizza',
  templateUrl: './edit-pizza.component.html',
  styleUrls: ['./edit-pizza.component.css']
})
export class EditPizzaComponent implements OnInit {
	pizza :Pizza;
	pizzaForm :FormGroup;

  constructor(private fb :FormBuilder) { 
  	this.pizzaForm = this.fb.group({
			'name': '',
			'description': '',
			'grade': '',
			'price': ''
		});
  }

  ngOnInit() {
  }

}
