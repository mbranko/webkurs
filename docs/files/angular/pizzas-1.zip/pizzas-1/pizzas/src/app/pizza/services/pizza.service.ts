import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { Pizza } from '../model/pizza.model';
import { PizzaSearchResult } from '../model/pizzaSearchResult.model';

const baseUrl = "http://localhost:3000/api/pizzas";

@Injectable()
export class PizzaService {
	
  	constructor( private http :HttpClient) {}

  	getAll() :Observable<PizzaSearchResult>{
  		return this.http.get(baseUrl).map( 
  			data => { return new PizzaSearchResult(data) }
  		);
  	}
}
