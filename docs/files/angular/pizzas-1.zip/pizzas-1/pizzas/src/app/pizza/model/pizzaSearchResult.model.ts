import { Pizza } from './pizza.model';

export class PizzaSearchResult{
	pizzas :Pizza[];
	count :number;

	constructor(obj? :any){
		this.pizzas = obj && obj.results.map(elem => { return new Pizza(elem); }) || [];
		/* Linija iznad ima isti efekat kao kod u ovom komentaru: 
		this.pizzas = [];
		for(let elem of obj.results){
			this.pizzas.push(new Pizza(elem));
		} */

		this.count = obj && obj.count || null;
	}	
}