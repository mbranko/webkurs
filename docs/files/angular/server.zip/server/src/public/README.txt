Uputstvo za pokretanje primera:

1. Podesiti server prema uputstvu sa slajdova (01_Angular_kontroleri_direktive_filteri.pdf, slajd 6). 
2. Sadrzaj ove arhive (direktorijum 01_Angular_Primeri i index.html) razmotati u direktorijum server_location\src\public. Pod server_location misli se na putanju na kojoj ste podesili server.
3. U browser uneti adresu http://localhost:3000 i odabrati zeljeni link.