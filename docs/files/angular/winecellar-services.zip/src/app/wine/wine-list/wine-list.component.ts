import { Component, OnInit, Input } from '@angular/core';

import { WineService } from '../services/wine.service';
import { Wine } from '../model/wine.model';

@Component({
  selector: 'wc-wine-list',
  templateUrl: './wine-list.component.html',
  styleUrls: ['./wine-list.component.css']
})
export class WineListComponent implements OnInit {
    private wineList :Wine[];

    constructor(private wineService :WineService) { }

  	ngOnInit() { 
  		 this.wineList = this.wineService.getAll();
  	}
}
