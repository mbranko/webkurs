import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Wine } from '../model/wine.model';

@Component({
  selector: 'wc-edit-wine',
  templateUrl: './edit-wine.component.html',
  styleUrls: ['./edit-wine.component.css']
})
export class EditWineComponent implements OnInit {
	wine :Wine;
	wineForm :FormGroup;

  	constructor(private fb: FormBuilder) { 
  		this.createForm();
  	}

  	ngOnInit() {}

  	createForm(){
  		this.wineForm = this.fb.group({
  			'name': ["", [Validators.required, Validators.minLength(2)]],
  			'year': ["", Validators.required],
  			'grapes': ["", Validators.required],
  			'country': ["", Validators.required],
  			'region': ["", Validators.required],
  			'description': ["", Validators.required]
  		});
  	}

  	onSubmit(){
  		this.wine = this.wineForm.value;
  		console.log(this.wine);
  		this.wineForm.reset();
  	}
}
