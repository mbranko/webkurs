import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Employee } from '../model/employee.model'

@Component({
	selector: 'app-edit-employee',
	templateUrl: './edit-employee.component.html',
	styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
	employee :Employee; 
	employeeForm :FormGroup;

	constructor(private fb: FormBuilder) {
		this.employee = new Employee({"_id": 1, "name": "Pera", "surname": "Peric", 
			"jmbg": "1234567891234", "email": "pera.peric@domain.com"});
		this.createForm();
		this.employeeForm.patchValue(this.employee);
	}

	ngOnInit() {}

	createForm() {
		this.employeeForm = this.fb.group({
			name: ['', Validators.required],
			surname: ['', Validators.required],
			jmbg: ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]],
			email: ['', [Validators.required, Validators.email]]
		});
	}

	onRevert(){
		// this.employeeForm.patchValue(this.employee);
		console.log(this.employeeForm.controls.errors);
	}

	onSubmit() {
		this.employee = this.employeeForm.value;
		console.log(this.employee);
		this.employeeForm.reset();
	}
}
