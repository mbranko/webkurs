export class Employee{
	_id :number;
	name :string;
	surname :string;
	jmbg :string;
	email :string;
	
	constructor(obj? :any){
		this._id = obj && obj._id || null;
		this.name = obj && obj.name || null;
		this.surname = obj && obj.surname || null;
		this.jmbg = obj && obj.jmbg || null;
		this.email = obj && obj.email || null;
	}
}