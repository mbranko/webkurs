import { Component, OnInit, Input } from '@angular/core';
import { Pizza } from '../model/pizza.model';

@Component({
	selector: 'app-pizza-details',
	templateUrl: './pizza-details.component.html',
	styleUrls: ['./pizza-details.component.css']
})
export class PizzaDetailsComponent implements OnInit {
	@Input() pizza :Pizza;
	
	constructor() {}

	ngOnInit() {}

	onSubmit(){}
}
