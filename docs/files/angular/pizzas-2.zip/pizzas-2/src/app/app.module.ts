import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { PizzaService } from './pizza/services/pizza.service';

import { AppComponent } from './app.component';
import { PizzaListComponent } from './pizza/pizza-list/pizza-list.component';
import { PizzaDetailsComponent } from './pizza/pizza-details/pizza-details.component';
import { EditPizzaComponent } from './pizza/edit-pizza/edit-pizza.component';
import { NavbarComponent } from './core/navbar/navbar.component';

const routes :Routes = [
  {path: 'pizzas', component: PizzaListComponent},
  {path: 'pizzas/add', component: EditPizzaComponent},
  {path: 'pizzas/:id', component: EditPizzaComponent},
  {path: '', redirectTo: '/pizzas', pathMatch: 'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    PizzaListComponent,
    PizzaDetailsComponent,
    EditPizzaComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [PizzaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
