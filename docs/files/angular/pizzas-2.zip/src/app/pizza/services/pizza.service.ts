import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { Pizza } from '../model/pizza.model';
import { PizzaSearchResult } from '../model/pizzaSearchResult.model';

const baseUrl = "http://localhost:3000/api/pizzas";

@Injectable()
export class PizzaService {
	
	constructor( private http :HttpClient) {}

	getAll(params? :any) :Observable<PizzaSearchResult>{

		let queryParams = {}
		if (params){
			queryParams = { params: new HttpParams()
				.set("pageSize", params.pageSize && params.pageSize.toString() || "")
				.set("page", params.page && params.page.toString() || "")
				.set("filter", params.filter && JSON.stringify(params.filter) || "")
				.set("sort", params.sort && params.sort.toString() || "")
				.set("sortDirection", params.sortDirection && params.sortDirection.toString() || "")
			}
		};

		return this.http.get(baseUrl, queryParams).map( 
			data => { return new PizzaSearchResult(data) 
		});
	}
}
