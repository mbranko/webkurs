import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'wc-edit-wine',
  templateUrl: './edit-wine.component.html',
  styleUrls: ['./edit-wine.component.css']
})
export class EditWineComponent implements OnInit {
	private wine = {};

  	constructor() { }

  	ngOnInit() {}

  	onSubmit(){
  		console.log(JSON.stringify(this.wine));
  	}
}
