import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
	registerUserForm :FormGroup;

  	constructor(private fb: FormBuilder) { 
  		this.createForm();
  	}

  	createForm(){
  		this.registerUserForm = this.fb.group({
  			username: '',
  			email: '',
  			password: ''
  		});
  	}

  	ngOnInit() { }

  	onSubmit(){
  		console.log(this.registerUserForm.value);
  		this.registerUserForm.reset();
  	}
}
